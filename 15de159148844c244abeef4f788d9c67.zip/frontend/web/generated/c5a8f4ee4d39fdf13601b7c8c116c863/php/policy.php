<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    

    <!-- Document Title -->
    <title>Моё дело</title>

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/png" href="assets/images/favicon.png">

    <!--==== Google Fonts ====-->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500%7CSpectral:400,400i,500,600,700" rel="stylesheet">

    <!-- CSS Files -->

    <!--==== Bootstrap css file ====-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--==== Font-Awesome css file ====-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">

    <!--==== Animate CSS ====-->
    <link rel="stylesheet" href="assets/plugins/animate/animate.min.css">

    <!--==== Owl Carousel ====-->
    <link rel="stylesheet" href="assets/plugins/owl-carousel/owl.carousel.min.css">

    <!--==== Magnific Popup ====-->
    <link rel="stylesheet" href="assets/plugins/magnific-popup/magnific-popup.css">

    <!--==== Style css file ====-->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--==== Custom css file ====-->
    <link rel="stylesheet" href="assets/css/custom.css">
</head>

<body>
<!-- Preloader -->
<div class="preloader">
    <div class="preload-img">
        <div class="spinnerBounce">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
    </div>
</div>
<!-- End of Preloader -->

<!-- Nav Search Box -->
<div class="nav-search-box">
    <form>
        <div class="input-group">
            <input class="form-control" placeholder="eg. feel the love and …" type="text">
            <span class="b-line"></span>
            <span class="b-line-under"></span>
            <div class="input-group-append">
                <button class="btn" type="button">
                    <img alt="" class="img-fluid svg" src="assets/images/search-icon.svg">
                </button>
            </div>
        </div>
    </form>
</div>
<!-- End of Nav Search Box -->

<!-- Header -->
<header class="header">
    <div class="header-fixed">
        <div class="container-fluid pl-120 pr-120 position-relative">
            <div class="row d-flex align-items-center">

                <div class="col-lg-3 col-md-4 col-6">
                    <!-- Logo -->
                    <h2 class="logo text-uppercase">
                        <a href="index.php">Доход</a>
                    </h2>
                    <!-- End of Logo -->
                </div>

                <div class="col-lg-9 col-md-8 col-6 d-flex justify-content-end position-static">
                    <!-- Nav Menu -->
                    <div class="nav-menu-cover">
                        <ul class="nav nav-menu">
                            <li><a href="index.php">Главная</a></li>
                            <li class="menu-item-has-children"><a href="#">Статьи</a>
                                <ul class="sub-menu">
                                    
                                    <li><a href="lQwNJxYpybs.php">Купить это и...</a></li>
                                    

                                    <li><a href="Amoyur4Z7uiLnyEoIsxPOR.php">Признаки де...</a></li>
                                    

                                    <li><a href="tOoREJzaNjpT0PeioylwF.php">5 способов з...</a></li>
                                    

                                    <li><a href="8eebaf2b5ed313e03d3b6dc72335bf4a.php">Три причины,...</a></li>
                                    

                                    <li><a href="10fd6ba9a6cf2d79a01ded32deb29e51.php">Как погасит...</a></li>
                                    

                                </ul>
                            </li>
                            <li><a href="contact.php">Контакты</a></li>
                        </ul>
                    </div>
                    <!-- End of Nav Menu -->

                    <!-- Mobile Menu -->
                    <div class="mobile-menu-cover">
                        <ul class="nav mobile-nav-menu">
                            <li class="search-toggle-open">
                                <img alt="" class="img-fluid svg" src="assets/images/search-icon.svg">
                            </li>
                            <li class="search-toggle-close hide">
                                <img alt="" class="img-fluid" src="assets/images/close.svg">
                            </li>
                            <li class="nav-menu-toggle">
                                <img alt="" class="img-fluid svg" src="assets/images/menu-toggler.svg">
                            </li>
                        </ul>
                    </div>
                    <!-- End of Mobile Menu -->
                </div>
            </div>
        </div>
    </div>
</header>
<!-- End of Header -->

<!-- Page title -->
<div class="page-title py-3">
    <div class="container">
        <ul class="nav">
            <li><a href="index.php">Главная</a></li>
            <li><a href="#">Политика конфиденциальности</a></li>
        </ul>
    </div>
</div>
<!-- End of Page title -->

<!-- Policy section -->
<div class="section mt-5">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <div class="col-md-8">
                <!-- post content -->
                <div class="section-row">
                    <h3>Политика конфиденциальности</h3>
                    <pre style="width:100%; white-space: pre-line!important;">
							Политика в отношении обработки персональных данных 1. Общие положения Настоящая политика обработки персональных данных составлена в соответствии с требованиями Федерального закона от 27.07.2006. №152-ФЗ «О персональных данных» и определяет порядок обработки персональных данных и меры по обеспечению безопасности персональных данных Михайлова Ивана Сергеевича (далее – Оператор). Оператор ставит своей важнейшей целью и условием осуществления своей деятельности соблюдение прав и свобод человека и гражданина при обработке его персональных данных, в том числе защиты прав на неприкосновенность частной жизни, личную и семейную тайну. Настоящая политика Оператора в отношении обработки персональных данных (далее – Политика) применяется ко всей информации, которую Оператор может получить о посетителях веб-сайта <span class="server-name"></span>.
							Основные понятия, используемые в Политике Автоматизированная обработка персональных данных – обработка персональных данных с помощью средств вычислительной техники; Блокирование персональных данных – временное прекращение обработки персональных данных (за исключением случаев, если обработка необходима для уточнения персональных данных); Веб-сайт – совокупность графических и информационных материалов, а также программ для ЭВМ и баз данных, обеспечивающих их доступность в сети интернет по сетевому адресу <span class="server-name"></span>;
							Информационная система персональных данных — совокупность содержащихся в базах данных персональных данных, и обеспечивающих их обработку информационных технологий и технических средств; Обезличивание персональных данных — действия, в результате которых невозможно определить без использования дополнительной информации принадлежность персональных данных конкретному Пользователю или иному субъекту персональных данных; Обработка персональных данных – любое действие (операция) или совокупность действий (операций), совершаемых с использованием средств автоматизации или без использования таких средств с персональными данными, включая сбор, запись, систематизацию, накопление, хранение, уточнение (обновление, изменение), извлечение, использование, передачу (распространение, предоставление, доступ), обезличивание, блокирование, удаление, уничтожение персональных данных; Оператор – государственный орган, муниципальный орган, юридическое или физическое лицо, самостоятельно или совместно с другими лицами организующие и (или) осуществляющие обработку персональных данных, а также определяющие цели обработки персональных данных, состав персональных данных, подлежащих обработке, действия (операции), совершаемые с персональными данными; Персональные данные – любая информация, относящаяся прямо или косвенно к определенному или определяемому Пользователю веб-сайта <span class="server-name"></span>;
							Пользователь – любой посетитель веб-сайта <span class="server-name"></span>;
							Предоставление персональных данных – действия, направленные на раскрытие персональных данных определенному лицу или определенному кругу лиц; Распространение персональных данных – любые действия, направленные на раскрытие персональных данных неопределенному кругу лиц (передача персональных данных) или на ознакомление с персональными данными неограниченного круга лиц, в том числе обнародование персональных данных в средствах массовой информации, размещение в информационно-телекоммуникационных сетях или предоставление доступа к персональным данным каким-либо иным способом; Трансграничная передача персональных данных – передача персональных данных на территорию иностранного государства органу власти иностранного государства, иностранному физическому или иностранному юридическому лицу; Уничтожение персональных данных – любые действия, в результате которых персональные данные уничтожаются безвозвратно с невозможностью дальнейшего восстановления содержания персональных данных в информационной системе персональных данных и (или) результате которых уничтожаются материальные носители персональных данных. Оператор может обрабатывать следующие персональные данные Пользователя Фамилия, имя, отчество; Электронный адрес; Номера телефонов; Год, месяц, дата и место рождения; Фотографии; Также на сайте происходит сбор и обработка обезличенных данных о посетителях (в т.ч. файлов «cookie») с помощью сервисов интернет-статистики (Яндекс Метрика и Гугл Аналитика и других). Вышеперечисленные данные далее по тексту Политики объединены общим понятием Персональные данные. Цели обработки персональных данных Цель обработки персональных данных Пользователя информирование Пользователя посредством отправки электронных писем; предоставление доступа Пользователю к сервисам, информации и/или материалам, содержащимся на веб-сайте. Также Оператор имеет право направлять Пользователю уведомления о новых продуктах и услугах, специальных предложениях и различных событиях. Пользователь всегда может отказаться от получения информационных сообщений, направив Оператору письмо на адрес электронной почты policy@<span
                            class="server-name"></span> с пометкой «Отказ от уведомлениях о новых продуктах и услугах и специальных предложениях». Обезличенные данные Пользователей, собираемые с помощью сервисов интернет-статистики, служат для сбора информации о действиях Пользователей на сайте, улучшения качества сайта и его содержания. Правовые основания обработки персональных данных Оператор обрабатывает персональные данные Пользователя только в случае их заполнения и/или отправки Пользователем самостоятельно через специальные формы, расположенные на сайте <span class="server-name"></span>. Заполняя соответствующие формы и/или отправляя свои персональные данные Оператору, Пользователь выражает свое согласие с данной Политикой. Оператор обрабатывает обезличенные данные о Пользователе в случае, если это разрешено в настройках браузера Пользователя (включено сохранение файлов «cookie» и использование технологии JavaScript). Порядок сбора, хранения, передачи и других видов обработки персональных данных Безопасность персональных данных, которые обрабатываются Оператором, обеспечивается путем реализации правовых, организационных и технических мер, необходимых для выполнения в полном объеме требований действующего законодательства в области защиты персональных данных. Оператор обеспечивает сохранность персональных данных и принимает все возможные меры, исключающие доступ к персональным данным неуполномоченных лиц. Персональные данные Пользователя никогда, ни при каких условиях не будут переданы третьим лицам, за исключением случаев, связанных с исполнением действующего законодательства. В случае выявления неточностей в персональных данных, Пользователь может актуализировать их самостоятельно, путем направления Оператору уведомление на адрес электронной почты Оператора policy@<span
                            class="server-name"></span> с пометкой «Актуализация персональных данных». Срок обработки персональных данных является неограниченным. Пользователь может в любой момент отозвать свое согласие на обработку персональных данных, направив Оператору уведомление посредством электронной почты на электронный адрес Оператора policy@<span class="server-name"></span> с пометкой «Отзыв согласия на обработку персональных данных». Трансграничная передача персональных данных Оператор до начала осуществления трансграничной передачи персональных данных обязан убедиться в том, что иностранным государством, на территорию которого предполагается осуществлять передачу персональных данных, обеспечивается надежная защита прав субъектов персональных данных. Трансграничная передача персональных данных на территории иностранных государств, не отвечающих вышеуказанным требованиям, может осуществляться только в случае наличия согласия в письменной форме субъекта персональных данных на трансграничную передачу его персональных данных и/или исполнения договора, стороной которого является субъект персональных данных. Заключительные положения Пользователь может получить любые разъяснения по интересующим вопросам, касающимся обработки его персональных данных, обратившись к Оператору с помощью электронной почты policy@<span
                            class="server-name"></span>.
							В данном документе будут отражены любые изменения политики обработки персональных данных Оператором. Политика действует бессрочно до замены ее новой версией. Актуальная версия Политики в свободном доступе расположена в сети Интернет по адресу <span class="server-name"></span>/policy.html.
						</pre>
                </div>
                <!-- /post content -->
            </div>
            <div class="col-md-4">
                <div class="pt-88">
                    <div class="my-sidebar">
                        <!-- Instagram Widget -->
                        <div class="widget widget-instagram">
                            <!-- Widget Title -->
                            <h4 class="widget-title">
                                Социальные медиа
                            </h4>
                            <!-- End of Widget Title -->

                            <!-- Widget Content -->
                            <div class="widget-content">
                                <ul class="insta-gallery">
                                    
                                    <li>
                                        <!-- Instagram Post Image -->
                                        <a href=""><img alt="" class="img-fluid" src="./img/katie-harp-agwt9nsitwu-unsplash.jpg"></a>
                                    </li>
                                    

                                    <li>
                                        <!-- Instagram Post Image -->
                                        <a href=""><img alt="" class="img-fluid" src="./img/mihaly-koles-fm5n2m9ogbi-unsplash.jpg"></a>
                                    </li>
                                    

                                    <li>
                                        <!-- Instagram Post Image -->
                                        <a href=""><img alt="" class="img-fluid" src="./img/image00031.jpg"></a>
                                    </li>
                                    

                                    <li>
                                        <!-- Instagram Post Image -->
                                        <a href=""><img alt="" class="img-fluid" src="./img/muhammad-rizki-rn3r-lki45m-unsplash.jpg"></a>
                                    </li>
                                    

                                    <li>
                                        <!-- Instagram Post Image -->
                                        <a href=""><img alt="" class="img-fluid" src="./img/zane-lee-fnhwqcvupgm-unsplash.jpg"></a>
                                    </li>
                                    

                                    <li>
                                        <!-- Instagram Post Image -->
                                        <a href=""><img alt="" class="img-fluid" src="./img/zane-lee-fnhwqcvupgm-unsplash.jpg"></a>
                                    </li>
                                    

                                </ul>
                                <!-- Instagram Follow Button -->
                                <a class="btn btn-block btn-instagram" href="">
                                    <i class="fa fa-instagram"></i> Подписаться
                                </a>
                            </div>
                            <!-- End of Widget Content -->
                        </div>
                        <!-- End of Instagram Widget -->

                        <!-- Recent Post Widget -->
                        <div class="widget widget-recent-post">
                            <!-- Widget Title -->
                            <h4 class="widget-title">
                                Недавние посты
                            </h4>
                            <!-- End of Widget Title -->

                            <!-- Widget Content -->
                            <div class="widget-content">
                                
                                <!-- Single Post -->
                                <div class="wrp-cover">
                                    <!-- Post Thumbnail -->
                                    <div class="post-thumb">
                                        <a href="lQwNJxYpybs.php">
                                            <img alt="" class="img-fluid" src="./img/katie-harp-agwt9nsitwu-unsplash.jpg">
                                        </a>
                                    </div>
                                    <!-- Post Title -->
                                    <div class="post-title">
                                        <a href="lQwNJxYpybs.php">Купить это или продать?</a>
                                    </div>
                                </div>
                                

                                <!-- Single Post -->
                                <div class="wrp-cover">
                                    <!-- Post Thumbnail -->
                                    <div class="post-thumb">
                                        <a href="Amoyur4Z7uiLnyEoIsxPOR.php">
                                            <img alt="" class="img-fluid" src="./img/mihaly-koles-fm5n2m9ogbi-unsplash.jpg">
                                        </a>
                                    </div>
                                    <!-- Post Title -->
                                    <div class="post-title">
                                        <a href="Amoyur4Z7uiLnyEoIsxPOR.php">Признаки денег и богатства</a>
                                    </div>
                                </div>
                                

                                <!-- Single Post -->
                                <div class="wrp-cover">
                                    <!-- Post Thumbnail -->
                                    <div class="post-thumb">
                                        <a href="tOoREJzaNjpT0PeioylwF.php">
                                            <img alt="" class="img-fluid" src="./img/image00031.jpg">
                                        </a>
                                    </div>
                                    <!-- Post Title -->
                                    <div class="post-title">
                                        <a href="tOoREJzaNjpT0PeioylwF.php">5 способов заработать больше денег (какие из них в данный момент работают на ваш кошелек)</a>
                                    </div>
                                </div>
                                

                            </div>
                            <!-- End of Widget Content -->
                        </div>
                        <!-- End of Recent Post Widget -->

                    </div>
                </div>
            </div>
    </div>
    <!-- /container -->
</div>
<!-- /SECTION -->

<!-- ****** Footer Menu Area Start ****** -->
<footer class="footer-container d-flex align-items-center">
    <div class="container">
        <div class="row align-items-center footer">
            <div class="col-md-12 text-center text-md-left order-md-1 order-2">
                <nav class="navbar navbar-expand-lg">
                    <button aria-controls="yummyfood-footer-nav" aria-expanded="false" aria-label="Toggle navigation"
                            class="navbar-toggler" data-target="#yummyfood-footer-nav"
                            data-toggle="collapse" type="button"><i aria-hidden="true"
                                                                    class="fa fa-bars"></i> Menu
                    </button>
                    <!-- Menu Area Start -->
                    <div class="collapse navbar-collapse justify-content-left" id="yummyfood-footer-nav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Главная <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Контакты</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="terms.php">Условия и положения</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="policy.php">Политика конфиденциальности</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="message_for_oss.php">Обращение к посетителям</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="footer-social">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-linkedin"></i></a>
                    <a href="#"><i class="fa fa-google"></i></a>
                    <a href="#"><i class="fa fa-pinterest"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- ****** Footer Menu Area End ****** -->

<!-- JS Files -->

<!-- ==== JQuery 1.12.1 js file ==== -->
<script src="assets/js/jquery-1.12.1.min.js"></script>

<!-- ==== Bootstrap js file ==== -->
<script src="assets/js/bootstrap.bundle.min.js"></script>

<!-- ==== Owl Carousel ==== -->
<script src="assets/plugins/owl-carousel/owl.carousel.min.js"></script>

<!-- ==== Magnific Popup ==== -->
<script src="assets/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- ==== Script js file ==== -->
<script src="assets/js/scripts.js"></script>

<!-- ==== Custom js file ==== -->
<script src="assets/js/custom.js"></script>

<div class='cookie-banner'>
    <p>
        Сайт использует файлы cookie. Они позволяют узнавать вас и получать информацию о вашем пользовательском опыте.Продолжая просмотр сайта, я соглашаюсь с использованием файлов cookie владельцем сайта в соответствии с <a href="https://en.wikipedia.org/wiki/HTTP_cookie" target="_blank">Политикой cookie</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>
<script>
    let elems = document.querySelectorAll('.server-name');
    elems.forEach((elem) => {
        elem.innerHTML = window.location.hostname
    })
</script>
</body>

</html>
