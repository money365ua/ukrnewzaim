<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">

    

    <!-- Document Title -->
    <title>Экономика</title>

    <!-- Favicon -->
    <link href="assets/images/favicon.png" rel="shortcut icon" type="image/png">

    <!--==== Google Fonts ====-->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500%7CSpectral:400,400i,500,600,700"
          rel="stylesheet">

    <!-- CSS Files -->

    <!--==== Bootstrap css file ====-->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!--==== Font-Awesome css file ====-->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">

    <!--==== Animate CSS ====-->
    <link href="assets/plugins/animate/animate.min.css" rel="stylesheet">

    <!--==== Owl Carousel ====-->
    <link href="assets/plugins/owl-carousel/owl.carousel.min.css" rel="stylesheet">

    <!--==== Magnific Popup ====-->
    <link href="assets/plugins/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!--==== Style css file ====-->
    <link href="assets/css/style.css" rel="stylesheet">

    <!--==== Custom css file ====-->
    <link href="assets/css/custom.css" rel="stylesheet">
</head>
<body>
<!-- Preloader -->
<div class="preloader">
    <div class="preload-img">
        <div class="spinnerBounce">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
    </div>
</div>
<!-- End of Preloader -->

<!-- Nav Search Box -->
<div class="nav-search-box">
    <form>
        <div class="input-group">
            <input class="form-control" placeholder="eg. feel the love and …" type="text">
            <span class="b-line"></span>
            <span class="b-line-under"></span>
            <div class="input-group-append">
                <button class="btn" type="button">
                    <img alt="" class="img-fluid svg" src="assets/images/search-icon.svg">
                </button>
            </div>
        </div>
    </form>
</div>
<!-- End of Nav Search Box -->

<!-- Header -->
<header class="header">
    <div class="header-fixed">
        <div class="container-fluid pl-120 pr-120 position-relative">
            <div class="row d-flex align-items-center">

                <div class="col-lg-3 col-md-4 col-6">
                    <!-- Logo -->
                    <h2 class="logo text-uppercase">
                        <a href="index.php">Моя зарплата</a>
                    </h2>
                    <!-- End of Logo -->
                </div>

                <div class="col-lg-9 col-md-8 col-6 d-flex justify-content-end position-static">
                    <!-- Nav Menu -->
                    <div class="nav-menu-cover">
                        <ul class="nav nav-menu">
                            <li><a href="index.php">Главная</a></li>
                            <li class="menu-item-has-children"><a href="#">Статьи</a>
                                <ul class="sub-menu">
                                    
                                    <li><a href="lQwNJxYpybs.php">Купить это и...</a></li>
                                    

                                    <li><a href="Amoyur4Z7uiLnyEoIsxPOR.php">Признаки де...</a></li>
                                    

                                    <li><a href="tOoREJzaNjpT0PeioylwF.php">5 способов з...</a></li>
                                    

                                    <li><a href="8eebaf2b5ed313e03d3b6dc72335bf4a.php">Три причины,...</a></li>
                                    

                                    <li><a href="10fd6ba9a6cf2d79a01ded32deb29e51.php">Как погасит...</a></li>
                                    

                                </ul>
                            </li>
                            <li><a href="contact.php">Контакты</a></li>
                        </ul>
                    </div>
                    <!-- End of Nav Menu -->

                    <!-- Mobile Menu -->
                    <div class="mobile-menu-cover">
                        <ul class="nav mobile-nav-menu">
                            <li class="search-toggle-open">
                                <img alt="" class="img-fluid svg" src="assets/images/search-icon.svg">
                            </li>
                            <li class="search-toggle-close hide">
                                <img alt="" class="img-fluid" src="assets/images/close.svg">
                            </li>
                            <li class="nav-menu-toggle">
                                <img alt="" class="img-fluid svg" src="assets/images/menu-toggler.svg">
                            </li>
                        </ul>
                    </div>
                    <!-- End of Mobile Menu -->
                </div>
            </div>
        </div>
    </div>
</header>
<!-- End of Header -->

<!-- Page title -->
<div class="page-title py-3">
    <div class="container">
        <ul class="nav">
            <li><a href="index.php">Главная</a></li>
            <li><a href="#">Статьи</a></li>
        </ul>
    </div>
</div>
<!-- End of Page title -->

<!-- Single post  -->
<div class="container pt-120">
    <div class="row">
        <div class="col-lg-8 pb-80">
            <div class="post-details-cover">
                <!-- Post Thumbnail -->
                <div class="post-thumb-cover">
                    <div class="post-thumb">
                        <img alt="" class="img-fluid" src="./img/zane-lee-fnhwqcvupgm-unsplash.jpg">
                    </div>
                    <!-- Post Meta Info -->
                    <div class="post-meta-info">
                        <!-- Title -->
                        <div class="title">
                            <h2>Как погасить ипотеку очень быстро и без штрафов</h2>
                        </div>

                        <!-- Meta -->
                        <ul class="nav meta align-items-center">
                            <li class="meta-author">
                                <img alt="" class="img-fluid" src="assets/images/blog/author.jpg">
                                <a href="#">Наталья Коноваловa</a>
                            </li>
                            <li class="meta-date">
                                <a href="#">05.11.2020</a></li>
                            <li> 14 min read</li>
                            <li class="meta-comments">
                                <a href="#"><i class="fa fa-comment"></i> 4</a>
                            </li>
                        </ul>
                    </div>
                    <!-- End of Post Meta Info -->
                </div>
                <!-- End oF Post Thumbnail -->

                <!-- Post Content -->
                <div class="post-content-cover my-drop-cap">
                    <p> <strong>Как погасить ипотеку очень быстро и без штрафов </strong>в 2017 году меня не удивило, что ипотека очень популярна у россиян. Ведь мы все знакомы с примером ипотеки на 15-20 лет, а сумма штрафов и штрафов огромна. Так зачем же нам вообще нужна такая процедура? "Просто - проще погасить ипотеку, чем подросток ее выплачивает", - отвечали они. Я бы согласился, что такая ситуация вполне естественна и вполне ожидаема. На самом деле, каждый из нас вполне способен принимать обоснованные решения, когда финансы ограничены. Так как же это получается Россияне пользуются такой финансовой безопасностью? Прежде всего, мы должны сделать что-то немедленно: мы не занимаем и не ссужаем деньги. Мы работаем и зарабатываем. Мы платим налоги. Мы сами себе платим. И мы получаем выгоду. Во-вторых, мы не вредим своей собственной жизни. Мы не следим за родительскими правами,не копим и не занимаем деньги. Мы не следим за здоровьем наших семей. Мы не ищем помощи для себя. Мы просто счастливы, что у нас есть ипотека. В-третьих, мы выплачиваем проценты по кредиту по ставке, которая в несколько раз превышает ставку по депозитам. Другими словами, срок ипотеки становится еще выше, если кредитная ставка подниматься. Но это не совсем так: если кредитная ставка пойдет вверх, то пациент будет только погашать долг в виде ежемесячного платежа, но он не пойдет в банк для дальнейшего погашения.  В-четвертых, мы не делаем обязательных платежей по ипотеке. На самом деле вам придется немного подождать (многие так и делают) и выбрать тот способ действий, который подходит именно вам. Но если вы ничего не делаете и стоите на месте, что ж, тогда вы переходите от простого заемщика к ипотечному кредитору. И, наконец, есть самый важный набор навыков.  И самое главное-это то, что она должна быть реализована! Достаточно придерживаться простых принципов и вообще ничего не делать, прекрасно зная, что денег нет. И ничего не делать, если, конечно, вы делаете что-то случайно (например, кладете руку на банковский стол и очень хорошо водите машину). Это очень важно ! Это наш шанс стать финансово грамотными. И именно благодаря этому шансу мы учимся экономить, учиться, учиться и учиться снова. И этой возможностью мы обязательно воспользуемся.  РЕЗЮМЕ: 1) Таким образом вы можете сэкономить деньги, потому что у вас есть 2 разных шанса разбогатеть: либо вас простит общество, либо вы сами сядет в тюрьму за "зло". 2) если один из них неблагоприятен, то другой будет неблагоприятен. 3) Главное отличие между вами и другими-это отношение к деньгам. Удача берет верх над шансами.  Главное - не брать ипотеку и думать о ее закрытии. Просто начните экономить деньги, и вы сможете прокормить свою семью в конце концов. Дополнительно: 1) прочитайте мою статью "Куда я не должен вкладывать свои деньги? ТОП-3 самых опасных мест для денег". 2) прочитайте мою статью "Какие навыки вам нужны, чтобы стать богатым" . Автор статьи-Александр Евстегнеев буду вам очень признателен ЛАЙКИ И РЕПОСТЫ ЭТОЙ СТАТЬИ</p>
                </div>
                <!-- End of Post Content -->

                <!-- Comment Form -->
                <div class="post-comment-form-cover">
                    <h3>Отправить комментарий</h3>
                    <form action="" class="comment-form">
                        <div class="row">
                            <div class="col-md-6">
                                <input class="form-control" placeholder="Имя" type="text">
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" placeholder="Email" type="text">
                            </div>
                            <div class="col-md-12">
                                <textarea class="form-control" placeholder="Отправить комментарий"></textarea>
                            </div>
                            <div class="col-md-12">
                                <button class="btn btn-primary">Отправить</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- End of Comment Form -->
            </div>
        </div>
        <div class="col-lg-4">
            <div class="my-sidebar">
                <!-- Instagram Widget -->
                <div class="widget widget-instagram">
                    <!-- Widget Title -->
                    <h4 class="widget-title">
                        Социальные медиа
                    </h4>
                    <!-- End of Widget Title -->

                    <!-- Widget Content -->
                    <div class="widget-content">
                        <ul class="insta-gallery">
                            
                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/katie-harp-agwt9nsitwu-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/mihaly-koles-fm5n2m9ogbi-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/image00031.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/muhammad-rizki-rn3r-lki45m-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/zane-lee-fnhwqcvupgm-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/zane-lee-fnhwqcvupgm-unsplash.jpg"></a>
                            </li>
                            

                        </ul>
                        <!-- Instagram Follow Button -->
                        <a class="btn btn-block btn-instagram" href="">
                            <i class="fa fa-instagram"></i> Подписаться
                        </a>
                    </div>
                    <!-- End of Widget Content -->
                </div>
                <!-- End of Instagram Widget -->

                <!-- Recent Post Widget -->
                <div class="widget widget-recent-post">
                    <!-- Widget Title -->
                    <h4 class="widget-title">
                        Недавние посты
                    </h4>
                    <!-- End of Widget Title -->

                    <!-- Widget Content -->
                    <div class="widget-content">
                        
                        <!-- Single Post -->
                        <div class="wrp-cover">
                            <!-- Post Thumbnail -->
                            <div class="post-thumb">
                                <a href="lQwNJxYpybs.php">
                                    <img alt="" class="img-fluid" src="./img/katie-harp-agwt9nsitwu-unsplash.jpg">
                                </a>
                            </div>
                            <!-- Post Title -->
                            <div class="post-title">
                                <a href="lQwNJxYpybs.php">Купить это или продать?</a>
                            </div>
                        </div>
                        

                        <!-- Single Post -->
                        <div class="wrp-cover">
                            <!-- Post Thumbnail -->
                            <div class="post-thumb">
                                <a href="Amoyur4Z7uiLnyEoIsxPOR.php">
                                    <img alt="" class="img-fluid" src="./img/mihaly-koles-fm5n2m9ogbi-unsplash.jpg">
                                </a>
                            </div>
                            <!-- Post Title -->
                            <div class="post-title">
                                <a href="Amoyur4Z7uiLnyEoIsxPOR.php">Признаки денег и богатства</a>
                            </div>
                        </div>
                        

                        <!-- Single Post -->
                        <div class="wrp-cover">
                            <!-- Post Thumbnail -->
                            <div class="post-thumb">
                                <a href="tOoREJzaNjpT0PeioylwF.php">
                                    <img alt="" class="img-fluid" src="./img/image00031.jpg">
                                </a>
                            </div>
                            <!-- Post Title -->
                            <div class="post-title">
                                <a href="tOoREJzaNjpT0PeioylwF.php">5 способов заработать больше денег (какие из них в данный момент работают на ваш кошелек)</a>
                            </div>
                        </div>
                        

                    </div>
                    <!-- End of Widget Content -->
                </div>
                <!-- End of Recent Post Widget -->

            </div>
        </div>
    </div>
</div>
<!-- End single post  -->

<!-- Newsletter -->
<section class="newsletter-cover">
    <!-- Overlay -->
    <div class="nl-bg-ol"></div>
    <div class="container">
        <div class="newsletter pt-80 pb-80">
            <!-- Section title -->
            <div class="section-title text-center">
                <h2>Рассылка</h2>
            </div>
            <!-- End of Section title -->
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <!-- Newsletter Form -->
                    <form action="thanks.php">
                        <div class="input-group">
                            <input class="form-control" placeholder="Email" type="text">
                            <div class="input-group-append">
                                <button class="btn btn-default">Подписаться</button>
                            </div>
                        </div>
                        -<p class="mt-4 checkbox-cover d-flex justify-content-center">
                        Введите ваш email чтобы получать новые статьи нашего блога.
                    </p>
                    </form>
                    <!-- End of Newsletter Form -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of Newsletter -->

<!-- Footer -->
<footer class="footer-container d-flex align-items-center">
    <div class="container">
        <div class="row align-items-center footer">
            <div class="col-md-12 text-center text-md-left order-md-1 order-2">
                <nav class="navbar navbar-expand-lg">
                    <button aria-controls="yummyfood-footer-nav" aria-expanded="false" aria-label="Toggle navigation"
                            class="navbar-toggler" data-target="#yummyfood-footer-nav"
                            data-toggle="collapse" type="button"><i aria-hidden="true"
                                                                    class="fa fa-bars"></i> Menu
                    </button>
                    <!-- Menu Area Start -->
                    <div class="collapse navbar-collapse justify-content-left" id="yummyfood-footer-nav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Главная <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Контакты</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="terms.php">Условия и положения</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="policy.php">Политика конфиденциальности</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="message_for_oss.php">Обращение к посетителям</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="footer-social">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-linkedin"></i></a>
                    <a href="#"><i class="fa fa-google"></i></a>
                    <a href="#"><i class="fa fa-pinterest"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End of Footer -->

<!-- Back to Top Button -->
<div class="back-to-top d-flex align-items-center justify-content-center">
    <span><i class="fa fa-long-arrow-up"></i></span>
</div>
<!-- End of Back to Top Button -->

<!-- JS Files -->

<!-- ==== JQuery 1.12.1 js file ==== -->
<script src="assets/js/jquery-1.12.1.min.js"></script>

<!-- ==== Bootstrap js file ==== -->
<script src="assets/js/bootstrap.bundle.min.js"></script>

<!-- ==== Owl Carousel ==== -->
<script src="assets/plugins/owl-carousel/owl.carousel.min.js"></script>

<!-- ==== Magnific Popup ==== -->
<script src="assets/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- ==== Script js file ==== -->
<script src="assets/js/scripts.js"></script>

<!-- ==== Custom js file ==== -->
<script src="assets/js/custom.js"></script>

<div class='cookie-banner'>
    <p>
        Сайт использует файлы cookie. Они позволяют узнавать вас и получать информацию о вашем пользовательском опыте.Продолжая просмотр сайта, я соглашаюсь с использованием файлов cookie владельцем сайта в соответствии с <a href="https://en.wikipedia.org/wiki/HTTP_cookie" target="_blank">Политикой cookie</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>

</body>
</html>