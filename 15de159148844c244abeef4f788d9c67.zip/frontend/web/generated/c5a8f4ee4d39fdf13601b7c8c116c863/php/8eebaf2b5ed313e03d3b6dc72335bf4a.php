<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">

    

    <!-- Document Title -->
    <title>Миллионер</title>

    <!-- Favicon -->
    <link href="assets/images/favicon.png" rel="shortcut icon" type="image/png">

    <!--==== Google Fonts ====-->
    <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500%7CSpectral:400,400i,500,600,700"
          rel="stylesheet">

    <!-- CSS Files -->

    <!--==== Bootstrap css file ====-->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">

    <!--==== Font-Awesome css file ====-->
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">

    <!--==== Animate CSS ====-->
    <link href="assets/plugins/animate/animate.min.css" rel="stylesheet">

    <!--==== Owl Carousel ====-->
    <link href="assets/plugins/owl-carousel/owl.carousel.min.css" rel="stylesheet">

    <!--==== Magnific Popup ====-->
    <link href="assets/plugins/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!--==== Style css file ====-->
    <link href="assets/css/style.css" rel="stylesheet">

    <!--==== Custom css file ====-->
    <link href="assets/css/custom.css" rel="stylesheet">
</head>
<body>
<!-- Preloader -->
<div class="preloader">
    <div class="preload-img">
        <div class="spinnerBounce">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
    </div>
</div>
<!-- End of Preloader -->

<!-- Nav Search Box -->
<div class="nav-search-box">
    <form>
        <div class="input-group">
            <input class="form-control" placeholder="eg. feel the love and …" type="text">
            <span class="b-line"></span>
            <span class="b-line-under"></span>
            <div class="input-group-append">
                <button class="btn" type="button">
                    <img alt="" class="img-fluid svg" src="assets/images/search-icon.svg">
                </button>
            </div>
        </div>
    </form>
</div>
<!-- End of Nav Search Box -->

<!-- Header -->
<header class="header">
    <div class="header-fixed">
        <div class="container-fluid pl-120 pr-120 position-relative">
            <div class="row d-flex align-items-center">

                <div class="col-lg-3 col-md-4 col-6">
                    <!-- Logo -->
                    <h2 class="logo text-uppercase">
                        <a href="index.php">Доллар</a>
                    </h2>
                    <!-- End of Logo -->
                </div>

                <div class="col-lg-9 col-md-8 col-6 d-flex justify-content-end position-static">
                    <!-- Nav Menu -->
                    <div class="nav-menu-cover">
                        <ul class="nav nav-menu">
                            <li><a href="index.php">Главная</a></li>
                            <li class="menu-item-has-children"><a href="#">Статьи</a>
                                <ul class="sub-menu">
                                    
                                    <li><a href="lQwNJxYpybs.php">Купить это и...</a></li>
                                    

                                    <li><a href="Amoyur4Z7uiLnyEoIsxPOR.php">Признаки де...</a></li>
                                    

                                    <li><a href="tOoREJzaNjpT0PeioylwF.php">5 способов з...</a></li>
                                    

                                    <li><a href="8eebaf2b5ed313e03d3b6dc72335bf4a.php">Три причины,...</a></li>
                                    

                                    <li><a href="10fd6ba9a6cf2d79a01ded32deb29e51.php">Как погасит...</a></li>
                                    

                                </ul>
                            </li>
                            <li><a href="contact.php">Контакты</a></li>
                        </ul>
                    </div>
                    <!-- End of Nav Menu -->

                    <!-- Mobile Menu -->
                    <div class="mobile-menu-cover">
                        <ul class="nav mobile-nav-menu">
                            <li class="search-toggle-open">
                                <img alt="" class="img-fluid svg" src="assets/images/search-icon.svg">
                            </li>
                            <li class="search-toggle-close hide">
                                <img alt="" class="img-fluid" src="assets/images/close.svg">
                            </li>
                            <li class="nav-menu-toggle">
                                <img alt="" class="img-fluid svg" src="assets/images/menu-toggler.svg">
                            </li>
                        </ul>
                    </div>
                    <!-- End of Mobile Menu -->
                </div>
            </div>
        </div>
    </div>
</header>
<!-- End of Header -->

<!-- Page title -->
<div class="page-title py-3">
    <div class="container">
        <ul class="nav">
            <li><a href="index.php">Главная</a></li>
            <li><a href="#">Статьи</a></li>
        </ul>
    </div>
</div>
<!-- End of Page title -->

<!-- Single post  -->
<div class="container pt-120">
    <div class="row">
        <div class="col-lg-8 pb-80">
            <div class="post-details-cover">
                <!-- Post Thumbnail -->
                <div class="post-thumb-cover">
                    <div class="post-thumb">
                        <img alt="" class="img-fluid" src="./img/muhammad-rizki-rn3r-lki45m-unsplash.jpg">
                    </div>
                    <!-- Post Meta Info -->
                    <div class="post-meta-info">
                        <!-- Title -->
                        <div class="title">
                            <h2>Три причины, по которым вы не можете разбогатеть</h2>
                        </div>

                        <!-- Meta -->
                        <ul class="nav meta align-items-center">
                            <li class="meta-author">
                                <img alt="" class="img-fluid" src="assets/images/blog/author.jpg">
                                <a href="#">Надежда Анисимовa</a>
                            </li>
                            <li class="meta-date">
                                <a href="#">05.11.2020</a></li>
                            <li> 9 min read</li>
                            <li class="meta-comments">
                                <a href="#"><i class="fa fa-comment"></i> 10</a>
                            </li>
                        </ul>
                    </div>
                    <!-- End of Post Meta Info -->
                </div>
                <!-- End oF Post Thumbnail -->

                <!-- Post Content -->
                <div class="post-content-cover my-drop-cap">
                    <p> <strong>Три причины, по которым вы не можете разбогатеть </strong>каждый год, возникают новые трудности для каждого из нас, в том числе и для тех, кто уже начал инвестировать. Новые идеи, новые возможности, новые источники дохода - они не исчезают с горизонта. Все они далеки от каждого из нас. Если у вас есть хоть одна из этих причин, то вряд ли вам удастся разбогатеть.  В этой статье мы поговорим о том, что они означают и как разбогатеть. Давайте вкратце поговорим о том, как избавиться от долгов, накопить "финансовую подушку", избавиться от бедности и избавиться от финансовых проблем. проблемы: 1) Если у вас есть долги, то вы потеряли все, чего достигли в области инвестирования, скажем, на небольшую сумму. И это не личный опыт, а осознанное решение, принятое вами. Ведь если у вас много долгов — это что-то значит для вас, что вы потеряли все. Это так, а не факт вашей жизни. Ваше богатство должно заключаться не в размере вашего дохода, а в вашем финансовом благополучии. Имея разные "активы", каждый из них индивидуально способен и богат. Давайте представим, что у вас есть долги. Вы получали жалованье, но не больше. В дополнение, деньги были перечислены на вашу собственность в виде коммунальных платежей, кредитов и штрафов. Вы решили построить гидроэлектростанцию, но все еще имеете кредиты, чтобы заплатить за нее. Как вы еще больше усложняете эту сложную финансовую ситуацию? Когда у вас есть несколько активов, которые постоянно заканчиваются, вы понимаете, что все сделали правильно, но за счет правильного вложения собственных сил, капитала и времени (получите эту сумму примерно за один месяц). В результате вы потеряли все: бизнес, репутацию, нервы, имущество, коммунальные услуги. Что же мне делать в этом случае ситуация? Прежде всего, немедленно прекратите пользоваться чужими деньгами. Не используйте свои собственные деньги для целей других людей, не переводите их себе и не используйте свои собственные средства для этой цели. Используйте все свои оставшиеся средства, чтобы погасить долги. 2) Если у вас есть кредиты, у вас также есть финансовая подушка Да, да, вы получили кредит, и у вас также есть финансовая подушка.  Возьмите кредитную карту и сэкономьте деньги, поднимите палец вверх, а затем попробуйте взять небольшой платеж по обязательству.  Но, на самом деле, этого недостаточно: вы также должны передать ответственность за погашение долга. одолжи кому-нибудь. Например, вы сами должны переложить ответственность за погашение долга на кого-то другого, и вы должны получать небольшие проценты на вложенные средства.  3) Если вы женаты , то ваш доход будет больше, чем ваш возраст, если в возрасте 50 лет вы богаты, то у вас есть пассивный доход. Если в 60 лет вы бедны-это ваш активный доход. Таким образом, дело в том, что и вы, и ваши дети сможете обойтись меньшим долговым бременем.  Конечно, вы также должны переложить ответственность за погашение долгов на кого-то другого, а когда кто-то другой выпускается, ваши дети получат возможность получить кредит или даже право купить себе новый автомобиль. Но главное-помнить, что время не делает вас богатым, а только улучшает ваше финансовое положение. Резюме: богатство - это результат времени (то есть процесса создания богатства), а не человека в одно и то же время. Дополнительно: 1) прочитайте мою статью "Куда я не должен вкладывать свои деньги? ТОП-3 самых опасных мест для денег". 2) прочитайте мою статью "Какие навыки вам нужны, чтобы стать богатым" . Автором статьи является Александр Евстегнеев я буду БЛАГОДАРЕН ЗА ВАШИ ЛАЙКИ И РЕПОСТЫ ЭТОЙ СТАТЬИ</p>
                </div>
                <!-- End of Post Content -->

                <!-- Comment Form -->
                <div class="post-comment-form-cover">
                    <h3>Отправить комментарий</h3>
                    <form action="" class="comment-form">
                        <div class="row">
                            <div class="col-md-6">
                                <input class="form-control" placeholder="Имя" type="text">
                            </div>
                            <div class="col-md-6">
                                <input class="form-control" placeholder="Email" type="text">
                            </div>
                            <div class="col-md-12">
                                <textarea class="form-control" placeholder="Отправить комментарий"></textarea>
                            </div>
                            <div class="col-md-12">
                                <button class="btn btn-primary">Отправить</button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- End of Comment Form -->
            </div>
        </div>
        <div class="col-lg-4">
            <div class="my-sidebar">
                <!-- Instagram Widget -->
                <div class="widget widget-instagram">
                    <!-- Widget Title -->
                    <h4 class="widget-title">
                        Социальные медиа
                    </h4>
                    <!-- End of Widget Title -->

                    <!-- Widget Content -->
                    <div class="widget-content">
                        <ul class="insta-gallery">
                            
                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/katie-harp-agwt9nsitwu-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/mihaly-koles-fm5n2m9ogbi-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/image00031.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/muhammad-rizki-rn3r-lki45m-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/zane-lee-fnhwqcvupgm-unsplash.jpg"></a>
                            </li>
                            

                            <li>
                                <!-- Instagram Post Image -->
                                <a href=""><img alt="" class="img-fluid" src="./img/zane-lee-fnhwqcvupgm-unsplash.jpg"></a>
                            </li>
                            

                        </ul>
                        <!-- Instagram Follow Button -->
                        <a class="btn btn-block btn-instagram" href="">
                            <i class="fa fa-instagram"></i> Подписаться
                        </a>
                    </div>
                    <!-- End of Widget Content -->
                </div>
                <!-- End of Instagram Widget -->

                <!-- Recent Post Widget -->
                <div class="widget widget-recent-post">
                    <!-- Widget Title -->
                    <h4 class="widget-title">
                        Недавние посты
                    </h4>
                    <!-- End of Widget Title -->

                    <!-- Widget Content -->
                    <div class="widget-content">
                        
                        <!-- Single Post -->
                        <div class="wrp-cover">
                            <!-- Post Thumbnail -->
                            <div class="post-thumb">
                                <a href="lQwNJxYpybs.php">
                                    <img alt="" class="img-fluid" src="./img/katie-harp-agwt9nsitwu-unsplash.jpg">
                                </a>
                            </div>
                            <!-- Post Title -->
                            <div class="post-title">
                                <a href="lQwNJxYpybs.php">Купить это или продать?</a>
                            </div>
                        </div>
                        

                        <!-- Single Post -->
                        <div class="wrp-cover">
                            <!-- Post Thumbnail -->
                            <div class="post-thumb">
                                <a href="Amoyur4Z7uiLnyEoIsxPOR.php">
                                    <img alt="" class="img-fluid" src="./img/mihaly-koles-fm5n2m9ogbi-unsplash.jpg">
                                </a>
                            </div>
                            <!-- Post Title -->
                            <div class="post-title">
                                <a href="Amoyur4Z7uiLnyEoIsxPOR.php">Признаки денег и богатства</a>
                            </div>
                        </div>
                        

                        <!-- Single Post -->
                        <div class="wrp-cover">
                            <!-- Post Thumbnail -->
                            <div class="post-thumb">
                                <a href="tOoREJzaNjpT0PeioylwF.php">
                                    <img alt="" class="img-fluid" src="./img/image00031.jpg">
                                </a>
                            </div>
                            <!-- Post Title -->
                            <div class="post-title">
                                <a href="tOoREJzaNjpT0PeioylwF.php">5 способов заработать больше денег (какие из них в данный момент работают на ваш кошелек)</a>
                            </div>
                        </div>
                        

                    </div>
                    <!-- End of Widget Content -->
                </div>
                <!-- End of Recent Post Widget -->

            </div>
        </div>
    </div>
</div>
<!-- End single post  -->

<!-- Newsletter -->
<section class="newsletter-cover">
    <!-- Overlay -->
    <div class="nl-bg-ol"></div>
    <div class="container">
        <div class="newsletter pt-80 pb-80">
            <!-- Section title -->
            <div class="section-title text-center">
                <h2>Рассылка</h2>
            </div>
            <!-- End of Section title -->
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <!-- Newsletter Form -->
                    <form action="thanks.php">
                        <div class="input-group">
                            <input class="form-control" placeholder="Email" type="text">
                            <div class="input-group-append">
                                <button class="btn btn-default">Подписаться</button>
                            </div>
                        </div>
                        -<p class="mt-4 checkbox-cover d-flex justify-content-center">
                        Введите ваш email чтобы получать новые статьи нашего блога.
                    </p>
                    </form>
                    <!-- End of Newsletter Form -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End of Newsletter -->

<!-- Footer -->
<footer class="footer-container d-flex align-items-center">
    <div class="container">
        <div class="row align-items-center footer">
            <div class="col-md-12 text-center text-md-left order-md-1 order-2">
                <nav class="navbar navbar-expand-lg">
                    <button aria-controls="yummyfood-footer-nav" aria-expanded="false" aria-label="Toggle navigation"
                            class="navbar-toggler" data-target="#yummyfood-footer-nav"
                            data-toggle="collapse" type="button"><i aria-hidden="true"
                                                                    class="fa fa-bars"></i> Menu
                    </button>
                    <!-- Menu Area Start -->
                    <div class="collapse navbar-collapse justify-content-left" id="yummyfood-footer-nav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php">Главная <span class="sr-only">(current)</span></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php">Контакты</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="terms.php">Условия и положения</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="policy.php">Политика конфиденциальности</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="message_for_oss.php">Обращение к посетителям</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <div class="footer-social">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-linkedin"></i></a>
                    <a href="#"><i class="fa fa-google"></i></a>
                    <a href="#"><i class="fa fa-pinterest"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- End of Footer -->

<!-- Back to Top Button -->
<div class="back-to-top d-flex align-items-center justify-content-center">
    <span><i class="fa fa-long-arrow-up"></i></span>
</div>
<!-- End of Back to Top Button -->

<!-- JS Files -->

<!-- ==== JQuery 1.12.1 js file ==== -->
<script src="assets/js/jquery-1.12.1.min.js"></script>

<!-- ==== Bootstrap js file ==== -->
<script src="assets/js/bootstrap.bundle.min.js"></script>

<!-- ==== Owl Carousel ==== -->
<script src="assets/plugins/owl-carousel/owl.carousel.min.js"></script>

<!-- ==== Magnific Popup ==== -->
<script src="assets/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>

<!-- ==== Script js file ==== -->
<script src="assets/js/scripts.js"></script>

<!-- ==== Custom js file ==== -->
<script src="assets/js/custom.js"></script>

<div class='cookie-banner'>
    <p>
        Сайт использует файлы cookie. Они позволяют узнавать вас и получать информацию о вашем пользовательском опыте.Продолжая просмотр сайта, я соглашаюсь с использованием файлов cookie владельцем сайта в соответствии с <a href="https://en.wikipedia.org/wiki/HTTP_cookie" target="_blank">Политикой cookie</a>
    </p>
    <button class='close-cookie'>&times;</button>
</div>
<script>
    window.onload = function () {
        $('.close-cookie').click(function () {
            $('.cookie-banner').fadeOut();
        })
    }
</script>

</body>
</html>